package com.example.apigrafik

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface ApiService {

    @GET("market/v2/get-movers")
    fun getTopGainers(
        @Header("X-RapidAPI-Key") apiKey: String,
        @Header("X-RapidAPI-Host") host: String,
        @Query("region") region: String
    ): Call<List<Stock>>
}