package com.example.apigrafik

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var stockAdapter: StockAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        fetchStockData()
    }

    private fun fetchStockData() {
        // Jalankan di thread terpisah untuk menghindari ANR (Application Not Responding)
        thread {
            try {
                val client = OkHttpClient()

                // Buat URL request untuk Alpha Vantage API
                val request = Request.Builder()
                    .url("https://alpha-vantage.p.rapidapi.com/query?function=TIME_SERIES_DAILY&symbol=MSFT&outputsize=compact&datatype=json")
                    .get()
                    .addHeader("x-rapidapi-key", "019c47d737msh2b095c08e575827p197234jsn2242565f5b5a")
                    .addHeader("x-rapidapi-host", "alpha-vantage.p.rapidapi.com")
                    .build()

                val response = client.newCall(request).execute()
                val responseData = response.body?.string()

                if (response.isSuccessful && !responseData.isNullOrEmpty()) {
                    val stocks = parseStockData(responseData)

                    // Cek apakah data stok tidak kosong
                    if (stocks.isNotEmpty()) {
                        // Update UI di thread utama
                        runOnUiThread {
                            stockAdapter = StockAdapter(stocks)
                            recyclerView.adapter = stockAdapter
                        }
                    } else {
                        runOnUiThread {
                            Toast.makeText(this, "No stock data available", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this, "Failed to fetch data", Toast.LENGTH_LONG).show()
                    }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun parseStockData(responseData: String): List<Stock> {
        val stockList = mutableListOf<Stock>()
        try {
            val jsonObject = JSONObject(responseData)

            // Ambil data harga saham
            val timeSeries = jsonObject.getJSONObject("Time Series (Daily)")

            // Log untuk melihat seluruh Time Series jika diperlukan
            Log.d("MainActivity", "Time Series: $timeSeries")

            // Ambil tanggal terbaru
            val latestDate = timeSeries.keys().next() // Ambil tanggal terbaru
            Log.d("MainActivity", "Latest Date: $latestDate") // Log tanggal terbaru

            // Ambil data harga dari tanggal terbaru
            val latestData = timeSeries.getJSONObject(latestDate)

            // Ambil harga dan volume dari tanggal terbaru
            val stockPrice = latestData.getDouble("4. close")  // Harga penutupan
            val stockChange = latestData.getDouble("5. volume")  // Volume, atau bisa diganti dengan persentase perubahan harga jika diperlukan

            // Simpan data stock ke dalam list
            stockList.add(Stock(
                symbol = "MSFT",
                stockName = "Microsoft",
                stockPrice = stockPrice,
                stockChange = stockChange
            ))

        } catch (e: Exception) {
            Log.e("MainActivity", "Error parsing data: ${e.message}")
        }

        return stockList
    }
}
