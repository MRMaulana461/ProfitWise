package com.example.apigrafik

data class Stock(
    val symbol: String,
    val stockName: String,
    val stockPrice: Double,
    val stockChange: Double
)
